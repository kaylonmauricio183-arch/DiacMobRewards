package br.diac.mobrewards;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.ChatColor;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;

public final class DiacMobRewards extends JavaPlugin implements Listener {
    private Economy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        RegisteredServiceProvider<Economy> provider =
                getServer().getServicesManager().getRegistration(Economy.class);

        if (provider == null || provider.getProvider() == null) {
            getLogger().severe("Nenhuma economia Vault foi encontrada. Confira se Vault e LiteEco estão carregados.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        economy = provider.getProvider();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("DiacMobRewards ativado. Economia: " + economy.getName());
        getLogger().info("Recompensas padrão habilitadas para mobs vivos; valores especiais ficam no config.yml.");
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        Entity entity = event.getEntity();

        // Não paga jogadores nem armor stands. Outros seres vivos (mobs) entram na regra.
        if (!(entity instanceof LivingEntity) || entity instanceof Player || entity instanceof ArmorStand) {
            return;
        }

        Player killer = event.getEntity().getKiller();
        if (killer == null || economy == null) {
            return;
        }

        String mobName = entity.getType().name().toUpperCase(Locale.ROOT);
        double amount = getConfig().getDouble("rewards." + mobName, defaultReward(entity));

        if (!Double.isFinite(amount) || amount <= 0.0) {
            return;
        }

        EconomyResponse response = economy.depositPlayer(killer, amount);
        if (!response.transactionSuccess()) {
            getLogger().warning("Falha ao pagar " + killer.getName() + " por matar " + mobName
                    + ": " + response.errorMessage);
            return;
        }

        String message = getConfig().getString("messages.reward",
                "&a+{amount} por derrotar {mob}!");
        message = message.replace("{amount}", economy.format(amount))
                .replace("{mob}", friendlyName(mobName));

        killer.sendMessage(color(message));
    }

    private double defaultReward(Entity entity) {
        if (entity instanceof Monster) {
            return getConfig().getDouble("default-reward.hostile", 10.0);
        }
        if (entity instanceof Animals) {
            return getConfig().getDouble("default-reward.passive", 5.0);
        }
        return getConfig().getDouble("default-reward.other", 5.0);
    }

    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender,
                             org.bukkit.command.Command command,
                             String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("mobreward")) {
            return false;
        }

        if (!sender.hasPermission("diacmobrewards.admin")) {
            sender.sendMessage(color(getConfig().getString("messages.no-permission",
                    "&cVocê não tem permissão.")));
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(color(getConfig().getString("messages.reload",
                    "&aConfiguração recarregada.")));
            return true;
        }

        sender.sendMessage(color(getConfig().getString("messages.usage",
                "&eUse: /mobreward reload")));
        return true;
    }

    private String friendlyName(String name) {
        String lower = name.toLowerCase(Locale.ROOT).replace('_', ' ');
        String[] words = lower.split(" ");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (result.length() > 0) result.append(' ');
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)));
                if (word.length() > 1) result.append(word.substring(1));
            }
        }
        return result.toString();
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }
}
