rootProject.name = "DiacMobRewards"
