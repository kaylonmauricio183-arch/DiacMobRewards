# DiacMobRewards 1.1.0 — DIAC SURVIVAL

Esta versão amplia as recompensas: qualquer entidade viva que possa morrer e tenha um jogador como matador recebe recompensa, exceto jogadores e armor stands. Isso cobre mobs passivos, hostis e outras criaturas vivas reconhecidas pelo Paper.

## Valores padrão

- Mobs hostis: $10
- Animais/passivos: $5
- Outras criaturas vivas: $5
- Zumbi: $10
- Esqueleto: $12
- Aranha: $10
- Creeper: $15
- Enderman: $30
- Wither: $150
- Ender Dragon: $250

Os valores individuais em `rewards` substituem as categorias padrão. Para desativar um mob específico, configure seu valor como `0`.

## Requisitos

- Paper 26.3
- Java 25
- Vault carregado
- LiteEco registrado como provedor de economia do Vault

## Compilar

Use JDK 25 e Gradle compatível com Java 25:

```bash
gradle build
```

Saída: `build/libs/DiacMobRewards-1.1.0.jar`.

## Instalar

1. Faça backup do servidor.
2. Pare o servidor.
3. Envie o JAR para `plugins`.
4. Inicie o servidor.
5. Confira `/plugins` e o console.
6. Teste com um zumbi e confira o saldo.

## Comando

`/mobreward reload` recarrega o config.yml. Apenas operadores têm a permissão por padrão.

## Limites importantes

- O pagamento acontece somente quando um jogador é identificado como matador direto.
- Esta versão não bloqueia recompensas de mobs vindos de spawners, ovos ou farms. Isso pode permitir farming de dinheiro; teste e ajuste os valores antes de abrir o servidor.
- O código foi preparado para compilar contra Paper 26.3, mas a integração real com LiteEco ainda precisa ser testada no servidor. Não há garantia de funcionamento antes desse teste.
